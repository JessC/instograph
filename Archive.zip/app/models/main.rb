class Main < ActiveRecord::Base

end
