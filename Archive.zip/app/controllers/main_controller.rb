class MainController < ApplicationController
# before_action :authenticate
# before_filter :authenticate <-what is this syntax???

def index
	# redirect_to Instagram.authorize_url(:redirect_uri => CALLBACK_URL)	


end     




def about
end

def contact
end

def post
end


# https://api.instagram.com/oauth/authorize/?client_id=client_id&redirect_uri=https://localhost:3000&response_type=code
end
