require 'test_helper'

class MainTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
