    require "instagram"

    Instagram.configure do |config|
    config.client_id = "714ec5ab06844d288ee1637fcb8db711"
    config.client_secret = "b3e732b64ea341a9b45dd4625619fb7e"
    end